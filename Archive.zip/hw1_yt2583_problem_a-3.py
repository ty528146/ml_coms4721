import numpy as np
import matplotlib.pyplot as plt
from numpy import *
from numpy.linalg import inv
import scipy
#import data
x_train = genfromtxt("X_train.csv", delimiter=',')
#print (x_train[:,:])
#delimiter=','is necessary
y_train = genfromtxt("y_train.csv", delimiter=',')
#print (y_train[:,:])
#print (y_train[:,:])
#Numpy is complaining because data is not 2D (it's either 1D or 
#delimiter=','is necessary
#*delimiter: the str used to separate data. 横纵坐标以 ',' 分割，因此给 delimiter 传入 ','

#---------------------SVD DECOMPOSITION---------------------------------------------------
U, S, V = np.linalg.svd(x_train, full_matrices = False)

df = np.arange(5001).astype(float)
# .astypechange type of matrix,number,..
# .astypechange type of matrix,number,..
for lambda_b in range(0,5001):
	sigma= 0.00
	for i in range(7):
		sigma=sigma+ S[i]*S[i]/(df[lambda_b]+S[i]*S[i])
	df[lambda_b] =sigma
#ALL SUM OF  DIMESION 
#--------------------------------calculate w_rr----------------------------------------------
#calculate w_rr
w_rr = np.zeros((5001, 7))
for lambda_a in range(0,5001):
	w_rr[lambda_a] = np.ravel(np.dot(np.dot(inv(lambda_a*np.identity(7)+np.dot(np.transpose(x_train),x_train)),np.transpose(x_train)),y_train))
        #w_rr[lambda_a] = np.ravel(((inv(lambda_a*np.identity(7)+(np.transpose(x_train))*x_train)*np.transpose(x_train))*y_train))
#ravel put all w_rr in sequence

#-------------------------------print result-------------------------------------------------
for j in range(7):
	plt.plot(df, w_rr[:,j], label='dimension '+str(j+1))
plt.legend(bbox_to_anchor=(0.33, 0.45))
plt.title("7 curves in problem (a)")
plt.xlabel(r'df($\lambda$)')
plt.ylabel('value in wrr')
plt.ylim(-6,4)
plt.grid(True)
plt.show()

