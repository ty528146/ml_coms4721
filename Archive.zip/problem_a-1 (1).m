clc;
close all;
load('X_train.csv');
load('y_train.csv');
load('X_test.csv');
load('y_test.csv');
[row_y_tr,col_y_tr]=size(y_train);
[row_x_tr,col_x_tr]=size(X_train);
[row_y_te,col_y_te]=size(y_test);
[row_x_te,col_x_te]=size(X_test);
%use the conclusion from problem 1 to calculate x hat
sum1 = 0;
for i = 1:row_y_tr
    sum1=sum1+y_train(i);
end
pi_hat=sum1/row_y_tr;
%use the conclusion from problem 1 to calculate theta_y1_hat
%for class 0
theta_y1_hat0=zeros(1,54);
for i = 1:54
    sum3= 0;
    for j = 1777:row_x_tr
        sum3 = sum3+X_train(j,i);
    end 
    theta_y1_hat0(i)= sum3/(row_x_tr-1776);
end 
% for class 1
theta_y1_hat1=zeros(1,54);
for i = 1:54
    sum2= 0;
    for j = 1:1776
        sum2 = sum2+X_train(j,i);
    end 
    theta_y1_hat1(i)= sum2/1776;
end 
% theta_y1_hat1
 %theta_y1_hat0
% row_x_tr
%use the conclusion from problem 1 to calculate theta_y2_hat
%for class 0
theta_y2_hat0=zeros(1,3);
for i = 1:3
    sum4=0;
    for j = 1777:row_x_tr
        sum4 = sum4+log(X_train(j,i+54));
    end 
    theta_y2_hat0(i)= (row_x_tr-1776)/sum4;
end 
%theta_y2_hat0
% for class 1
theta_y2_hat1=zeros(1,3);
for i = 1:3
    sum5=0;
    for j = 1:1776
        sum5 = sum5+log(X_train(j,i+54));
    end 
    theta_y2_hat1(i)= 1776/sum5;
end 
%theta_y2_hat1


%%prediction on y

y_out = zeros(row_y_te,1);
p1 = ones(row_y_te,1);
p0 = ones(row_y_te,1);
%for class 1
for i = 1:row_y_te
 
    for j = 1:54
        p1(i) = p1(i)*theta_y1_hat1(j)^(X_test(i,j))*(1-theta_y1_hat1(j))^(1-X_test(i,j));
    end 
    for k = 1:3
        p1(i) = p1(i)*theta_y2_hat1(k)*(X_test(i,k+54))^(-(theta_y2_hat1(k)+1));
    end
    p1(i) = p1(i)*pi_hat;
%for class 0    
    for j2 = 1:54
       p0(i) = p0(i)*theta_y1_hat0(j2)^(X_test(i,j2))*(1-theta_y1_hat0(j2))^(1-X_test(i,j2));
    end 
    for k2 = 1:3
       p0(i) = p0(i)*theta_y2_hat0(k2)*(X_test(i,k2+54))^(-(theta_y2_hat0(k2)+1));
    end 
    p0(i)=p0(i)*(1-pi_hat);
    if (p1(i)/p0(i)) > 1
        y_out(i) = 1;
    else
        y_out(i) = 0;
    end 
end 
%print result
correct1 = 0;
correct0 = 0;
wrong_1_for_0 = 0;
wrong_0_for_1 = 0;
for i = 1:row_y_te
    
    if (y_test(i) == 0 && y_out(i)==0)
        correct0 = 1+correct0;
    elseif (y_test(i) == 1 && y_out(i) == 1)
        correct1 = 1+correct1;
    elseif (y_test(i) == 1 && y_out(i) == 0)
        wrong_1_for_0 = wrong_1_for_0+1;
     elseif (y_test(i) == 0 && y_out(i) == 1)   
         wrong_0_for_1 =  wrong_0_for_1 +1;
    end
end
correct1
correct0
wrong_1_for_0
wrong_0_for_1
%{
subplot(2,1,1);
grid on;
stem(1:54,theta_y1_hat1); 
title('problem2b');
xlabel('54 Bernoulli parameters class1');
ylabel('values of Bernoulli parameters');

subplot(2,1,2);
stem(1:54,theta_y1_hat0); 
title('problem2b');
xlabel('54 Bernoulli parameters class0');
ylabel('values of Bernoulli parameters');
%}
%legend('class 1','class 0');
%theta_y1_hat1
%theta_y1_hat0
stem(1:54,theta_y1_hat1); 
title('problem2b');
xlabel('54 Bernoulli parameters class1');
ylabel('values of Bernoulli parameters');
hold on
stem(1:54,theta_y1_hat0); 
title('problem2b');
xlabel('54 Bernoulli parameters class0');
ylabel('values of Bernoulli parameters');
legend('class 1','class 0');

