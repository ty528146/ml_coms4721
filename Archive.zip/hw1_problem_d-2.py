import numpy as np
import matplotlib.pyplot as plt
from numpy import *
from numpy.linalg import inv
import scipy
#import data
x_train = genfromtxt("X_train.csv", delimiter=',')
#print (x_train[:,:])
#delimiter=','is necessary
y_train = genfromtxt("y_train.csv", delimiter=',')
x_test = genfromtxt('X_test.csv', delimiter=',')
y_test = genfromtxt('y_test.csv', delimiter=',')
#print (y_train[:,:])
#print (y_train[:,:])
#Numpy is complaining because data is not 2D (it's either 1D or 
#delimiter=','is necessary
#*delimiter: the str used to separate data. 横纵坐标以 ',' 分割，因此给 delimiter 传入 ','


#--------------------------------calculate w_rr----------------------------------------------
#calculate w_rr
w_rr = np.zeros((5001, 7))
for lambda_a in range(0,5001):
	w_rr[lambda_a] = np.ravel(np.dot(np.dot(inv(lambda_a*np.identity(7)+np.dot(np.transpose(x_train),x_train)),np.transpose(x_train)),y_train))
        #w_rr[lambda_a] = np.ravel(((inv(lambda_a*np.identity(7)+(np.transpose(x_train))*x_train)*np.transpose(x_train))*y_train))
#ravel put all w_rr in sequence
#--------------------- PROBLEM D-------------------------------------------------------------
#p=1
y =np.arange(501)
rmse_1 = np.zeros(501)
for i in range(0,501):
	rmse_1[i] = np.sqrt(((y_test - np.dot(x_test, w_rr[i]))**2).mean())
	
#P=2
p2 = np.concatenate((x_train[:,0:6], np.square(x_train)), axis=1)
w_rr_2 = np.zeros((501, 13))
for i in range(0,501):
	w_rr_2[i] = np.ravel(np.dot(np.dot(inv(i*np.identity(13)+np.dot(np.transpose(p2),p2)),np.transpose(p2)),y_train))
x2 = np.concatenate((x_test[:,0:6], np.square(x_test)), axis=1)
rmse_2 = np.zeros(501)
for i in range(0,501):
	rmse_2[i] = np.sqrt(((y_test - np.dot(x2, w_rr_2[i]))**2).mean())
	
#P = 3
p3 = np.concatenate((x_train[:,0:6], np.square(x_train[:,0:6]), np.power(x_train,3)), axis=1)
w_rr_3 = np.zeros((501, 19))
for i in range(0,501):
	w_rr_3[i] = np.ravel(np.dot(np.dot(inv(i*np.identity(19)+np.dot(np.transpose(p3),p3)),np.transpose(p3)),y_train))
x3 = np.concatenate((x_test[:,0:6], np.square(x_test[:,0:6]), np.power(x_test,3)), axis=1)
rmse_3 = np.zeros(501)
for i in range(0,501):
	rmse_3[i] = np.sqrt(((y_test - np.dot(x3, w_rr_3[i]))**2).mean())
plt.title("RMSE AS FUNTION OF LAMBDA")
plt.plot(y, rmse_1, label="p = 1")
plt.plot(y, rmse_2, label="p = 2")
plt.plot(y, rmse_3, label="p = 3")
plt.xlabel(r'$\lambda$')
plt.ylabel("root mean squared error(RMSE)")
plt.grid(True)
plt.legend(bbox_to_anchor=(.8, 0.3))
plt.show()

