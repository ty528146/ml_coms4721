function [L,c,miu_k]=calculate(K,Y,n)
miu_k = rand(K,2);
Y_ = 0;
U_ = 0;
	% update the value of c(i) for every data point 
	% for each time of  20 iterations, only initialize c(i) = zeros(500,1) once
L = zeros(20,1);
c = zeros(500,1);
for ite = 1:20
        j = 1;
		for i = 1:n
			abs_c_square = zeros(K,1);
			% K clusters and for each cluster and each miu, calculate a least square, for k cluster is a k by 1 vector 
		    for j = 1:K
		    	abs_c_square(j) = norm (Y(i,:)-miu_k(j,:))^2;
		    end
		    % for every data point, assign a label to it according to least square
		    [Y_,U_] = min(abs_c_square);
		    c(i) = U_;
		end
		% this is for updating miu_k
		miu_k = zeros(K,2);
		for k = 1:K
			n_k = 0;
			for i = 1:n
				if c(i) == k
					n_k = n_k + 1;
					miu_k(k,:) =  miu_k(k,:)+Y(i,:); 
				end
			end
			miu_k(k,:) = 1/n_k*miu_k(k,:);
		end
		%% update the objective function
		for i = 1:n
			%% data points
			for j = 1:K
				% each cluster
				if c(i) == j
                    L(ite) =  L(ite) + norm (Y(i,:)-miu_k(j,:))^2;
                end 
			end
		end
end 
