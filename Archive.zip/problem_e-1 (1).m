clear all;
load('X_train.csv');
load('y_train.csv');
load('X_test.csv');
load('y_test.csv');
%%%add the offset on x traning data and x test data
y_train(y_train==0)=-1;
y_test(y_test==0)=-1;
%%get the size of the problem
[row_y_tr,col_y_tr]=size(y_train);
[row_x_tr,col_x_tr]=size(X_train);
[row_y_te,col_y_te]=size(y_test);
[row_x_te,col_x_te]=size(X_test);
%initialize w
w = zeros(58,1);
L = zeros(100,1);
acc = zeros(100,1);
a = ones(row_x_tr,1);
b = ones(row_x_te,1);
%%%add the offset on x traning data and x test data
X_train = [a X_train];
X_test = [b X_test];
for ite=1:100
    gradient_1 = zeros(58,1);
    gradient_2 =zeros(58,58);
    sigma_i_addon = 0;
    sigma_i = 0;
    for i = 1: row_x_tr
        sigma_i = max(10^(-100),1/(1+exp(-X_train(i,:)*w)));
        sigma_i_addon = max(10^(-100), 1/(1+exp(-y_train(i)*X_train(i,:)*w)));
        %sigma_i_addon = max(10^(-100),exp(y_train(i)*X_train(i,:)*w)/(1+exp(y_train(i)*X_train(i,:)*w)));
        gradient_1 = gradient_1+(1-sigma_i_addon)* y_train(i)*X_train(i,:).';
        gradient_2 = gradient_2 - sigma_i*(1-sigma_i)*X_train(i,:)'* X_train(i,:);
        %%should be transpose and corresponding elements multipled it is a
        %%constanty_train(i) multiply a vector %% sigma_i_addon also a
        %%constant not a vector check transpose because w is58 by 1 vector
        %grad_2 is a matrix 58 by 58
        L(ite) =  L(ite) + log(sigma_i_addon);
    end 
    w = w - 1/sqrt(ite+1)*inv(gradient_2)*gradient_1;
    prediction = zeros(row_y_te,1);
    prediction = sign(X_test*w);
    sum1 = 0;
    for j = 1:row_y_te
        if (prediction(j)==y_test(j))
            sum1 = sum1+1;
        end 
    end 
    acc(ite) = sum1/row_x_te;
end
itera = 1:100;
figure(1)
plot(itera,L);
grid on;
acc'
title('Newton Method');
xlabel('iterations');
ylabel('objective function');
figure(2)
plot(itera,acc);
title('Accuracy');
xlabel('iterations');
ylabel('accuracy');
