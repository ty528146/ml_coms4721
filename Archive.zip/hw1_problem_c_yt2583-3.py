import numpy as np
import matplotlib.pyplot as plt
from numpy import *
from numpy.linalg import inv
import scipy
#import data
x_train = genfromtxt("X_train.csv", delimiter=',')
#print (x_train[:,:])
#delimiter=','is necessary
y_train = genfromtxt("y_train.csv", delimiter=',')
#print (y_train[:,:])
#print (y_train[:,:])
#Numpy is complaining because data is not 2D (it's either 1D or 
#delimiter=','is necessary
#*delimiter: the str used to separate data. 横纵坐标以 ',' 分割，因此给 delimiter 传入 ','


#--------------------------------calculate w_rr----------------------------------------------
#calculate w_rr
w_rr = np.zeros((5001, 7))
for lambda_a in range(0,5001):
	w_rr[lambda_a] = np.ravel(np.dot(np.dot(inv(lambda_a*np.identity(7)+np.dot(np.transpose(x_train),x_train)),np.transpose(x_train)),y_train))
        #w_rr[lambda_a] = np.ravel(((inv(lambda_a*np.identity(7)+(np.transpose(x_train))*x_train)*np.transpose(x_train))*y_train))
#ravel put all w_rr in sequence

#------------------------PROBLEM C----------------------------------------------------------
x_test = genfromtxt('X_test.csv', delimiter=',')
y_test = genfromtxt('y_test.csv', delimiter=',')
rmse = np.zeros(51)
for i in range(51):
	rmse[i] = np.sqrt(((y_test - np.dot(x_test, w_rr[i]))**2).mean())
y =np.arange(51).astype(float)
plt.title('RMSE AS FUNTION OF LAMBDA')
plt.plot(y,rmse[:])
plt.xlabel(r'$\lambda$')
plt.ylabel("root mean squared error(RMSE)")
plt.grid(True)
plt.show()
print ( w_rr)

