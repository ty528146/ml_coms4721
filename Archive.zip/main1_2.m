%clc;
clear all;
%{
first generate500 observation  data points 
mu = [2 3];
SIGMA = [1 0; 0 2];
r = mvnrnd(mu,SIGMA,100);
plot(r(:,1),r(:,2),'r+');
hold on;
mu = [7 8];
SIGMA = [ 1 0; 0 2];
r2 = mvnrnd(mu,SIGMA,100);
plot(r2(:,1),r2(:,2),'*')
======================
MU1 = [1 2];
SIGMA1 = [2 0; 0 .5];
MU2 = [-3 -5];
SIGMA2 = [1 0; 0 1];
X = [mvnrnd(MU1,SIGMA1,1000);mvnrnd(MU2,SIGMA2,1000)];

scatter(X(:,1),X(:,2),10,'.')
hold on

L = [1 2 3 4 5;2 3 4 5 6;3 4 5 6 7];
plot(L);
legend('a','b','c');
%%plot according to colums ,# lines = #columns
%}
%% the value for mu
%%  https://www.mathworks.com/help/stats/gmdistribution.random.html
%% gaussian mixture distribution
%% https://www.mathworks.com/help/stats/gmdistribution.html
%% https://www.mathworks.com/help/matlab/ref/cat.html
%mu = [0 0;3 0;0 3];
%p = [1/3 1/3 1/3];
% p is a weight row vector
% The cat function concatenates the covariances along the third array di
% mension. The defined covariance matrices are diagonal matrices. sigma(1,:,i) contains the diagonal elements of the covariance matrix of component i.
%sigma = cat(3,[1 0;0 1],[1 0;0 1],[1 0;0 1]);
%gm = gmdistribution(mu,sigma,p);
%n = 1500;
mu1 = [0 0];
mu2 = [3 0];
mu3 = [0 3];
sigma1 = [1 0;0 1];
sigma2 = [1 0;0 1];
sigma3 = [1 0;0 1];
Y1 = mvnrnd(mu1,sigma1,500);
Y2 = mvnrnd(mu2,sigma2,500);
Y3 = mvnrnd(mu3,sigma3,500);
p1 = 0.2;
p2 = 0.5;
p3 = 0.3;
Y = Y1*p1+Y2*p2+Y2*p3;
n = 500;
%Y = random(gm,n);
%scatter(Y(:,1),Y(:,2),10,'.')
%K= 3;


L_all = zeros(20,5);

for k = 2:5
    %L_all(:,1)=zeros(20,1);
    c = zeros(500,1);
    L = zeros(20,1);
    miu_k = rand(k,2);
    [L,c,miu_k]=calculate1(k,Y,n);
    L_all(:,k) = L;
  k
if k==3 
    figure(1);
    plot(Y(c==1,1),Y(c==1,2),'c.','MarkerSize',10)
    hold on
    plot(Y(c==2,1),Y(c==2,2),'b.','MarkerSize',10)
    plot(Y(c==3,1),Y(c==3,2),'g.','MarkerSize',10)
    plot(miu_k(:,1),miu_k(:,2),'k*','MarkerSize',8,'LineWidth',2)
    legend('Cluster 1','Cluster 2','Cluster 3','Centroids');
    title('3 Clusters and Centroids');
    hold off
end
 %{   
if k==4
    figure(2);
    plot(Y(c==1,1),Y(c==1,2),'c.','MarkerSize',10)
    hold on
    plot(Y(c==2,1),Y(c==2,2),'b.','MarkerSize',10)
    plot(Y(c==3,1),Y(c==3,2),'g.','MarkerSize',10)
    plot(Y(c==4,1),Y(c==4,2),'g.','MarkerSize',10)
    plot(miu_k(:,1),miu_k(:,2),'k*','MarkerSize',12,'LineWidth',2)
    legend('Cluster 1','Cluster 2','Cluster 3','cluster 4''Centroids');
    title('4 Clusters and Centroids');
    hold off
end
 %}   
if k==5
    figure(3)
    plot(Y(c==1,1),Y(c==1,2),'c.','MarkerSize',10)
    hold on
    plot(Y(c==2,1),Y(c==2,2),'b.','MarkerSize',10)
    plot(Y(c==3,1),Y(c==3,2),'g.','MarkerSize',10)
    plot(Y(c==4,1),Y(c==4,2),'y.','MarkerSize',10)
    plot(Y(c==5,1),Y(c==5,2),'m.','MarkerSize',10)
    plot(miu_k(:,1),miu_k(:,2),'k*','MarkerSize',8,'LineWidth',2)
    legend('cluster 1','cluster 2','cluster 3','cluster 4','cluster 5','Centroids');
    title('5 Clusters and Centroids');
    hold off
end

    
end 
figure(4)
plot(L_all(:,2:5))
legend('K=2','K=3','K=4','K=5');
xlabel('the number of iterations');
ylabel('the value of objective function');
title('objective function for different K values');
