clc;
clear all;
close all;
load('X_train.csv');
load('y_train.csv');
load('X_test.csv');
load('y_test.csv');
[row_y_tr,col_y_tr]=size(y_train);
[row_x_tr,col_x_tr]=size(X_train);
[row_y_te,col_y_te]=size(y_test);
[row_x_te,col_x_te]=size(X_test);

y_out = zeros(row_y_te,1);
pre_acc = zeros(20,1);
for k = 1:20
    sum1 = 0;
    for i = 1:row_y_te
        for j = 1:row_x_tr
        distance(j) = sum(abs(X_train(j,:)-X_test(i,:)));
        %%traintimes ponits idstance to one definite test points
        end 
    %%find the nearesst points sort distance
    [dis,indice1] = sort(distance);%%this is to sort the matrix according to ascending order
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for w = 1:k %%k nearest points to vote and find the corresponding y label
        near_map_y(w) = y_train(indice1(w));%the length of near_map_y changes every time
    end 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    y_out(i) = mode(near_map_y);%% return the most frequent times
     %the length of near_map_y changes every time
    %%%never define sum or it will pops up 
    %%Subscript indices must either be real positive integers or logicals.
    if (y_out(i)==y_test(i))
        sum1 = sum1 + 1;
    end 
    end
    pre_acc(k) = sum1/row_y_te;
end
k = 1:20;
plot(k,pre_acc,'b');
title('Problemc k-NN algorithm');
xlabel('k');
ylabel('Prediction accuracy');
grid on;
sum1