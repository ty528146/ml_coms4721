load('X_train.csv');
load('y_train.csv');
load('X_test.csv');
load('y_test.csv');
[row_y_tr,col_y_tr]=size(y_train);
[row_x_tr,col_x_tr]=size(X_train);
[row_y_te,col_y_te]=size(y_test);
[row_x_te,col_x_te]=size(X_test);
%%% add the offset on x traning data and x test data
a = ones(row_x_tr,1);
b = ones(row_x_te,1);
X_train_new = [a X_train];
X_test_new = [b X_test];
[r_new_tr,c_new_tr] = size(X_train_new);
[r_new_te,c_new_te] = size(X_test_new);
%%%%%%%%%Initialize the following variables%%%%%%%%%%%%%
%for altogether T times iteration each iteration the weight for each point keeps changing 
wt = 1*ones(r_new_tr,1)/r_new_tr;% first round is uniform distribution
%%%%%%%%%%%%%%%%determine the total iteration and e_t and alpha_t 
%%%%%for each iteration et and alpha t is a number
T = 1500;
e_t = zeros(T,1);
alpha_t = zeros(T,1);
%%%%%initialize each iteration calculate the ls classifier weight%%%%%%%%
wr_ls = zeros(T,c_new_tr);
train_err = zeros(T,1);
test_err = zeros(T,1);
% initialize upper bound
upperbound = ones(T,1);
% initialize a list of index to keep track of selected x and corresponding y
list_of_index = [];

for t = 1:T
     %{
    [Y,I] = datasample(...) returns an index vector indicating which values
    were sampled from DATA.  For example, Y = DATA(I) if DATA is a vector,
    Y = DATA(I,:) if DATA is a matrix, etc.
        %}
    [X_sample,index] = datasample(X_train_new,1036,'Weights',wt);
    list_of_index = [list_of_index index];
    % Draw T times bootstrap  data set not unique values from the whole data set
    % according to specified probabilities from the data set
    %form each data set
    y_sample = y_train(index);% is a vector of 1036 elements
   %{
    if t == 12
        y_bag
    end
    %}
    %%%%%%%%%%%Learn a classifier using the data set Bt
    %%%%%%%%%%%sample the corresponding data points to calculate w in each%%%%%%%%%%%%%%%%
    %%%use ls classifiers to predict the sign of ys for each bag%%%%%%
    %for every data set calculate the classifier
    wr_ls(t,:) =((inv(X_sample'*X_sample)*X_sample')*y_sample);%%% the least square regressionweight vector
    if t ==12
        inv(X_sample'*X_sample)
    end
    %%%%%%%%%%%everytime interation predict once
    %%%%%%%%%%%%%%%%the middle training error
    temp = sign(X_train_new*wr_ls (t,:)');
    misclassifed = sign(abs(temp-y_train));
    e_t(t) = wt'*misclassifed;
    %%%%%%%%%%%if et >0.5, flip the sign%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if e_t(t)>0.5
        wr_ls(t,:)=(-1)*wr_ls(t,:);
        temp = sign(X_train_new*wr_ls(t,:)');%%%first
        misclassifed = sign(abs(temp-y_train));
        e_t(t) = wt'*misclassifed;
    end
  %%%%%%%%%%%%%%%%%%%%%%%%%use e t to calculate alpha t%%%%%%%%%%%%%%%%%%
    alpha_t(t) = 0.5*log((1-e_t(t))/e_t(t));
    for i = 1:r_new_tr
        wt(i) = wt(i)*exp(-alpha_t(t)*temp(i)*y_train(i));
    end
    wt = wt/sum(wt);
    train_each = zeros(r_new_tr,t);
    for i = 1:t
        train_each(:,i) = sign(X_train_new*wr_ls (i,:)')*alpha_t(i);
    end
   %add up all element in  each row
    train_all = sign(sum(train_each, 2));
    train_err(t) = sum(sign(abs(train_all-y_train)))/r_new_tr;
    % calculate the testing error
    test_each = zeros(r_new_te,t);
    for i = 1:t
        test_each(:,i) = sign(X_test_new*wr_ls (i,:)')*alpha_t(i);
    end
    test_all = sign(sum(test_each, 2));
    test_err(t) = sum(sign(abs(test_all-y_test)))/r_new_tr;
   
    sum_err = 1;
    for i = 1:t
        sum_err = sum_err * exp(-2*(0.5-e_t(i))^2);
    end
    upperbound(t) = sum_err;
end
figure(1)
plot(train_err)
grid on
hold on
plot(test_err)
legend('training error','testing error')
title('training and testing error');
%{
%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(2)
plot(upperbound)
title('Upperbound');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(3)
length(list_of_index)
histogram(list_of_index);
legend('histogram');
title('Total times of each training data point');
%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(4)
plot(e_t)
legend('et');
title('Training error as a function of t');
%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(5)
plot(alpha_t)
legend('alpha');
title('alpha as a function of t');
%}