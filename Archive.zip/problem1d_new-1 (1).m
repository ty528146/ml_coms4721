clc;
close all;
% choose the value of b
b = 5;
% choose the value of sigma2
sigma2 = 2;
load('X_train.csv');
load('y_train.csv');
load('X_test.csv');
load('y_test.csv');
[row_y_tr,col_y_tr]=size(y_train);
[row_x_tr,col_x_tr]=size(X_train);
[row_y_te,col_y_te]=size(y_test);
[row_x_te,col_x_te]=size(X_test);
K = ones(row_x_tr,row_x_tr);
x_axis = X_train(:,4);
% calculate Kernel n*n matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:row_x_tr
	for j = 1:row_x_tr
		K(i,j) = exp(-1/b*normest(X_train(i,4)-X_train(j,4)).^2);
	end
end 

dup = ones(row_x_tr,row_x_tr);
for i = 1:row_x_tr
	for j = 1:row_x_tr
		dup(i,j) = exp(-1/b*normest(X_train(i,4)-X_train(j,4)).^2);
	end 
end 
% Calculate the mean of mu_x and regard it as the prediction of y_test
mu_train = dup*inv(sigma2*eye(row_x_tr)+K)*y_train;
mu_train
scatter(x_axis, y_train);
hold on;
[x_axis_sorted,index] = sort(x_axis);
plot(x_axis_sorted,mu_train(index),'b');
grid on;
legend('scattered real points','predictive mean');
title('Gaussian process for prediction versus testing points');


