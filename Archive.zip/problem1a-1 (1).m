clc;
close all;
% choose the value of b
b = 15;
% choose the value of sigma2
sigma2 = 0.1;
load('X_train.csv');
load('y_train.csv');
load('X_test.csv');
load('y_test.csv');
[row_y_tr,col_y_tr]=size(y_train);
[row_x_tr,col_x_tr]=size(X_train);
[row_y_te,col_y_te]=size(y_test);
[row_x_te,col_x_te]=size(X_test);
K = ones(row_x_tr,row_x_tr);
% calculate Kernel n*n matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i = 1:row_x_tr
	for j = 1:row_x_tr
		K(i,j) = exp(-1/b*normest(X_train(i,:)-X_train(j,:)).^2);
	end
end 
% Calculate the K_Dn which is not a square matrix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
K_Dn = ones(row_x_te,row_x_tr);
for i = 1:row_x_te
	for j = 1:row_x_tr
		K_Dn(i,j) = exp(-1/b*normest(X_test(i,:)-X_train(j,:)).^2);
	end 
end 
% Calculate the mean of mu_x and regard it as the prediction of y_test
mu_x = K_Dn*inv(sigma2*eye(row_x_tr)+K)*y_train;
mu_x'