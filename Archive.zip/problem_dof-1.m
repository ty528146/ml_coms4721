
clear all;

load('X_train.csv');
load('y_train.csv');
load('X_test.csv');
load('y_test.csv');
% replace case 0 with case -1
y_train(y_train==0)=-1;
y_test(y_test==0)=-1;
%%get the size of the problem
[row_y_tr,col_y_tr]=size(y_train);
[row_x_tr,col_x_tr]=size(X_train);
[row_y_te,col_y_te]=size(y_test);
[row_x_te,col_x_te]=size(X_test);
w = zeros(58,1);
L = zeros(10000,1);
a = ones(row_x_tr,1);
%%%add the offset on x traning data and x test data
X_train = [a X_train];
c = 1/((10^5)*1);
for ite=1:10000
    w_1 = zeros(58,1); 
    gradient_i = zeros(58,1);
    for i = 1: row_x_tr
        sigma_i_addon = max(10^(-100), 1/(1+exp(-y_train(i)*X_train(i,:)*w)));
        gradient_i = gradient_i+(1-sigma_i_addon)* y_train(i)*X_train(i,:).';
        %%should be transpose and corresponding elements multipled it is a
        %%constanty_train(i) multiply a vector %% sigma_i_addon also a
        %%constant not a vector check transpose because w is58 by 1 vector
        L(ite) =  L(ite) + log(sigma_i_addon);
    end 
    w = w + (c/sqrt(ite+1))*gradient_i;
    
end
itera = 1:10000;
plot(itera,L);
grid on;
title('Logistic regression algorithm');
xlabel('iterations');
ylabel('Logistic regression training function');
%{
     5
     6
K>> c=1
c =
     1
K>> cat(1,a,b,c)//???cat(????????,????????,????????)
ans =
    1
     2
     5
     6
     1//???????????????????????
K>> cat(2,a,b)
ans =
     1     5
     2     6//??????????2????????????
K>> cat(3,a,b)
ans(:,:,1) =
     1
     2//?
%}