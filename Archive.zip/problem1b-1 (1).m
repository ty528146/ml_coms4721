load('X_train.csv');
load('y_train.csv');
load('X_test.csv');
load('y_test.csv');
[row_y_tr,col_y_tr]=size(y_train);
[row_x_tr,col_x_tr]=size(X_train);
[row_y_te,col_y_te]=size(y_test);
[row_x_te,col_x_te]=size(X_test);
K = ones(row_x_tr,row_x_tr);
K_Dn = ones(row_x_te,row_x_tr);
difference = zeros(6, 10);
mu_x = zeros(42,1);
sigma2 = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1];
b_range = [5,7,9,11,13,15];
for b = 1:6
    for s = 1:10
        for i = 1:row_x_tr
            for j = 1:row_x_tr
                    K(i,j) = exp(-1/b_range(b)*norm((X_train(i,:) - X_train(j,:)),2).^2);%%%%%
                    %%%%%%%%%%%%%norm faster than normest
            end
        end
        for i = 1:row_x_te
            for j = 1:row_x_tr
                 K_Dn(i,j) = exp(-1/b_range(b)*norm((X_test(i,:) - X_train(j,:)),2).^2);
            end
        end
        mu_x = K_Dn*inv (sigma2(s)*eye(row_x_tr)+K)*y_train;
        % RMSE difference
        difference(b,s) = sqrt((y_test - mu_x).'*(y_test - mu_x)/42);
    end
end
difference
